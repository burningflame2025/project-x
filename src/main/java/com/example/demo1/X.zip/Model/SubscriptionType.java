package com.example.demo1.Model;

enum SubscriptionType {NONE, BLUE, GOLD}
