package com.example.demo1.Model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

//=======database======
public class Database {
    private static Database instance;

    private List<User> users;
    private List<Post> posts;
    private List<Hashtag> hashtags;
    private List<Report> reports;
    private Admin admin;

    private Database() {
        users = new ArrayList<>();
        posts = new ArrayList<>();
        hashtags = new ArrayList<>();
        reports = new ArrayList<>();
        admin = Admin.getInstance();

        hashtags.add(new Hashtag("#News"));
        hashtags.add(new Hashtag("#Sports"));
        hashtags.add(new Hashtag("#Education"));
        hashtags.add(new Hashtag("#Iran"));
    }

    public static Database getInstance() {
        if (instance == null) {
            instance = new Database();
        }
        return instance;
    }

    //===============user methods===========
    public void addUser(User user) {
        users.add(user);
    }

    public void removeUser(User user) {
        users.remove(user);
    }

    public User getUserById(int id) {
        for (User u : users) {
            if (u.getId() == id) {
                return u;
            }
        }
        return null;
    }

    public User getUserByUsername(String username) {
        for (User u : users) {
            if (u.getUsername().equals(username)) {
                return u;
            }
        }
        return null;
    }

    public List<User> getUsers() {
        return new ArrayList<>(users);
    }

    public List<User> getLockedUsers() {
        List<User> locked = new ArrayList<>();
        for (User u : users) {
            if (u.isLocked()) {
                locked.add(u);
            }
        }
        return locked;
    }

    //====post methods======
    public void addPost(Post post) {
        posts.add(post);
    }

    public void removePost(Post post) {
        posts.remove(post);
    }

    public Post getPostById(int id) {
        for (Post p : posts) {
            if (p.getId() == id) {
                return p;
            }
        }
        return null;
    }

    public List<Post> getPostsByUserId(int userId) {
        List<Post> userPosts = new ArrayList<>();
        for (Post p : posts) {
            if (p.getAuthorId() == userId && !p.isDeleted()) {
                userPosts.add(p);
            }
        }
        return userPosts;
    }

    public List<Post> getPostsByHashtagId(int hashtagId) {
        Hashtag hashtag = getHashtagById(hashtagId);
        if (hashtag == null) return new ArrayList<>();

        List<Post> hashtagPosts = new ArrayList<>();
        for (int postId : hashtag.getPostIds()) {
            Post p = getPostById(postId);
            if (p != null && !p.isDeleted()) {
                hashtagPosts.add(p);
            }
        }
        return hashtagPosts;
    }

    public List<Post> getAllPosts() {
        List<Post> activePosts = new ArrayList<>();
        for (Post p : posts) {
            if (!p.isDeleted()) {
                activePosts.add(p);
            }
        }
        return activePosts;
    }

    public List<Post> getPopularPosts(int limit) {
        List<Post> allActivePosts = getAllPosts();
        Collections.sort(allActivePosts, new Comparator<Post>() {
            @Override
            public int compare(Post p1, Post p2) {
                return Integer.compare(p2.getLikeCount(), p1.getLikeCount());
            }
        });

        List<Post> popular = new ArrayList<>();
        int count = Math.min(limit, allActivePosts.size());
        for (int i = 0; i < count; i++) {
            popular.add(allActivePosts.get(i));
        }
        return popular;
    }

    //=======hashtag methods========
    public void addHashtag(Hashtag hashtag) {
        hashtags.add(hashtag);
    }

    public Hashtag getHashtagById(int id) {
        for (Hashtag h : hashtags) {
            if (h.getId() == id) {
                return h;
            }
        }
        return null;
    }

    public Hashtag getHashtagByTitle(String title) {
        String formatted = title.startsWith("#") ? title : "#" + title;
        for (Hashtag h : hashtags) {
            if (h.getTitle().equals(formatted)) {
                return h;
            }
        }
        return null;
    }

    public Hashtag getOrCreateHashtag(String title) {
        Hashtag existing = getHashtagByTitle(title);
        if (existing != null) return existing;

        Hashtag newHashtag = new Hashtag(title);
        hashtags.add(newHashtag);
        return newHashtag;
    }

    public List<Hashtag> getHashtags() {
        return new ArrayList<>(hashtags);
    }

    public List<Hashtag> getPopularHashtags() {
        List<Hashtag> sortedHashtags = new ArrayList<>(hashtags);
        Collections.sort(sortedHashtags, new Comparator<Hashtag>() {
            @Override
            public int compare(Hashtag h1, Hashtag h2) {
                return Integer.compare(h2.getUsageCount(), h1.getUsageCount());
            }
        });

        return sortedHashtags;
    }

    //=====report methods===
    public void addReport(Report report) {
        reports.add(report);
    }

    public Report getReportById(int id) {
        for (Report r : reports) {
            if (r.getId() == id) {
                return r;
            }
        }
        return null;
    }

    public List<Report> getReportsByStatus(ReportStatus status) {
        List<Report> filteredReports = new ArrayList<>();
        for (Report r : reports) {
            if (r.getStatus() == status) {
                filteredReports.add(r);
            }
        }
        return filteredReports;
    }

    public List<Report> getAllReports() {
        return new ArrayList<>(reports);
    }

    //=====other=======
    public void updateUser(User user) {
        for (int i = 0; i < users.size(); i++) {
            if (users.get(i).getId() == user.getId()) {
                users.set(i, user);
                break;
            }
        }
    }

    public Admin getAdmin() {
        return admin;
    }

    public void dailyTokenRecharge() {
        for (User user : users) {
            int currentTokens = user.getTokens();
            int minTokens = 250;
            if (user instanceof GoldUser) minTokens = 600;
            else if (user instanceof BlueUser) minTokens = 400;

            if (currentTokens < minTokens) {
                user.addTokens(user.getDailyTokenRecharge());
            }
        }
    }
}
