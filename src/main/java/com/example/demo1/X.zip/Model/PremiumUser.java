package com.example.demo1.Model;

import java.util.Date;

//====premium========
public abstract class PremiumUser extends User {
    protected Date subscriptionExpiry;
    protected boolean autoRenew;

    public PremiumUser(String username, String password, String email, String phone,
                       String firstName, String lastName) {
        super(username, password, email, phone, firstName, lastName);
        this.subscriptionExpiry = null;
        this.autoRenew = false;
    }

    public PremiumUser(User normalUser) {
        super(normalUser.getUsername(), normalUser.getPassword(),
                normalUser.getEmail(), normalUser.getPhone(),
                normalUser.getFirstName(), normalUser.getLastName());

        this.id = normalUser.getId();
        this.setTokens(normalUser.getTokens() + 3000);
        this.setBio(normalUser.getBio());
        for (int followerId : normalUser.getFollowers()) {
            this.addFollower(followerId);
        }
        for (int followingId : normalUser.getFollowing()) {
            this.followUser(followingId);
        }
        for (int postId : normalUser.getPostIds()) {
            this.addPostId(postId);
        }
        for (int hashtagId : normalUser.getSelectedHashtagIds()) {
            this.addSelectedHashtag(hashtagId);
        }
    }

    public void activateSubscription(int months) {
        if (subscriptionExpiry == null) {
            subscriptionExpiry = new Date();
        }
        long newTime = subscriptionExpiry.getTime() + (months * 30L * 24 * 60 * 60 * 1000);
        subscriptionExpiry = new Date(newTime);
    }

    public boolean isSubscriptionValid() {
        if (subscriptionExpiry == null) return true;
        return subscriptionExpiry.after(new Date());
    }

    public void extendSubscription(int months) {
        activateSubscription(months);
    }

    public int getDaysRemaining() {
        if (subscriptionExpiry == null) return 0;
        long diff = subscriptionExpiry.getTime() - new Date().getTime();
        return (int) (diff / (1000 * 60 * 60 * 24));
    }

    public Date getSubscriptionExpiry() {
        return subscriptionExpiry;
    }

    public void setSubscriptionExpiry(Date expiry) {
        this.subscriptionExpiry = expiry;
    }

    public boolean isAutoRenew() {
        return autoRenew;
    }

    public void setAutoRenew(boolean autoRenew) {
        this.autoRenew = autoRenew;
    }
}
