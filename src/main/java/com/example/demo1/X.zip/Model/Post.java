package com.example.demo1.Model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Post {
    private static int nextId = 1;

    private int id;
    private String text;
    private int authorId;
    private Media media;
    private List<Integer> hashtagIds;
    private List<Integer> likeUserIds;
    private List<Integer> replyIds;
    private Integer parentPostId;
    private int views;
    private boolean isLocked;
    private boolean isDeleted;
    private Date createdDate;
    private int reportCount;

    public Post(String text, int authorId, Media media, Integer parentPostId) {
        this.id = nextId++;
        this.text = text;
        this.authorId = authorId;
        this.media = media;
        this.parentPostId = parentPostId;
        this.hashtagIds = new ArrayList<>();
        this.likeUserIds = new ArrayList<>();
        this.replyIds = new ArrayList<>();
        this.views = 0;
        this.isLocked = false;
        this.isDeleted = false;
        this.createdDate = new Date();
        this.reportCount = 0;
    }

    public void addLike(int userId) {
        if (!likeUserIds.contains(userId)) {
            likeUserIds.add(userId);
        }
    }

    public void removeLike(int userId) {
        likeUserIds.remove(Integer.valueOf(userId));
    }

    public void addView() {
        this.views++;
    }

    public void addReply(int replyId) {
        this.replyIds.add(replyId);
    }

    public void addHashtag(int hashtagId) {
        if (!hashtagIds.contains(hashtagId)) {
            hashtagIds.add(hashtagId);
        }
    }

    public void increaseReportCount() {
        this.reportCount++;
    }

    public boolean isLikedByUser(int userId) {
        return likeUserIds.contains(userId);
    }

    public int getLikeCount() {
        return likeUserIds.size();
    }

    public int getReplyCount() {
        return replyIds.size();
    }

    public boolean isReply() {
        return parentPostId != null;
    }

    public int getId() {
        return id;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public int getAuthorId() {
        return authorId;
    }

    public Media getMedia() {
        return media;
    }

    public List<Integer> getHashtagIds() {
        return new ArrayList<>(hashtagIds);
    }

    public List<Integer> getLikeUserIds() {
        return new ArrayList<>(likeUserIds);
    }

    public List<Integer> getReplyIds() {
        return new ArrayList<>(replyIds);
    }

    public Integer getParentPostId() {
        return parentPostId;
    }

    public int getViews() {
        return views;
    }

    public boolean isLocked() {
        return isLocked;
    }

    public void setLocked(boolean locked) {
        isLocked = locked;
    }

    public boolean isDeleted() {
        return isDeleted;
    }

    public void setDeleted(boolean deleted) {
        isDeleted = deleted;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public int getReportCount() {
        return reportCount;
    }
}
