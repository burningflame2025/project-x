package com.example.demo1.Model;

enum MediaType {PHOTO, VIDEO}
