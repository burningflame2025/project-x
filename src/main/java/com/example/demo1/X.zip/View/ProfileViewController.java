package com.example.demo1.View;

import com.example.demo1.Model.User;
import com.example.demo1.XApplication;
import javafx.event.ActionEvent;
import com.example.demo1.Controller.PostController;
import com.example.demo1.Controller.UserController;
import com.example.demo1.Model.*;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;

import java.util.List;

public class ProfileViewController {

    @FXML private Label lblUsername;
    @FXML private Label lblFullName;
    @FXML private Label lblBio;
    @FXML private Label lblFollowers;
    @FXML private Label lblFollowing;
    @FXML private Label lblTokens;
    @FXML private Label lblPostsCount;
    @FXML private VBox postsContainer;
    @FXML private ScrollPane scrollPane;

    @FXML private TextArea txtBio;
    @FXML private Button btnEditSave;
    @FXML private Button btnFollow;

    private User currentUser;
    private User viewedUser;
    private UserController userController = new UserController();
    private PostController postController = new PostController();
    private Database db = Database.getInstance();
    private boolean isEditing = false;

    @FXML
    private void initialize() {
        if (txtBio != null) txtBio.setVisible(false);
        if (btnFollow != null) btnFollow.setVisible(false);
    }

    public void setCurrentUser(User currentUser){
        this.currentUser = currentUser;
    }

    public void setViewedUser(User viewedUser) {
        this.viewedUser = viewedUser;
        loadProfile();
    }

    private void loadProfile() {
        if (viewedUser == null) return;

        lblUsername.setText("@" + viewedUser.getUsername() + " " + viewedUser.getSubscriptionBadge());
        lblFullName.setText(viewedUser.getFullName());
        lblBio.setText(viewedUser.getBio().isEmpty() ? "No bio yet" : viewedUser.getBio());
        lblFollowers.setText("Followers: " + viewedUser.getFollowers().size());
        lblFollowing.setText("Following: " + viewedUser.getFollowing().size());

        if (lblTokens != null) lblTokens.setText("Tokens: " + viewedUser.getTokens());

        List<Post> userPosts = userController.getUserPosts(viewedUser.getId());
        if (lblPostsCount != null) lblPostsCount.setText("Posts: " + userPosts.size());

        loadPosts(userPosts);

        if (currentUser.getId() == viewedUser.getId()) {
            if (btnEditSave != null) btnEditSave.setVisible(true);
            if (btnFollow != null) btnFollow.setVisible(false);
        } else {
            if (btnEditSave != null) btnEditSave.setVisible(false);
            if (btnFollow != null) {
                btnFollow.setVisible(true);
                updateFollowButtonText();
            }
        }
    }

    private void updateFollowButtonText() {
        boolean isFollowing = currentUser.getFollowing().contains(viewedUser.getId());
        btnFollow.setText(isFollowing ? "Unfollow" : "Follow");
    }

    @FXML
    public void handleFollow(ActionEvent event) {
        if (currentUser == null || viewedUser == null) return;

        boolean isFollowing = currentUser.getFollowing().contains(viewedUser.getId());

        if (isFollowing) {
            userController.unfollowUser(currentUser.getId(), viewedUser.getId());
        } else {
            userController.followUser(currentUser.getId(), viewedUser.getId());
        }

        updateFollowButtonText();

        User updatedViewedUser = db.getUserById(viewedUser.getId());
        if (updatedViewedUser != null) {
            lblFollowers.setText("Followers: " + updatedViewedUser.getFollowers().size());
        }
    }

    private void loadPosts(List<Post> posts) {
        if (postsContainer == null) return;

        postsContainer.getChildren().clear();

        if (posts.isEmpty()) {
            postsContainer.getChildren().add(new Label("No posts yet!"));
            return;
        }

        for (Post post : posts) {
            VBox card = new VBox(5);
            Label text = new Label(post.getText());
            text.setWrapText(true);
            Label stats = new Label("Likes: " + post.getLikeCount() + " | Replies: " + post.getReplyCount() + " | Views: " + post.getViews());
            card.getChildren().addAll(text, stats);
            postsContainer.getChildren().add(card);
        }
    }

    @FXML
    public void handleEditSave(ActionEvent event) {
        if (!isEditing) {
            isEditing = true;
            txtBio.setText(viewedUser.getBio());
            txtBio.setVisible(true);
            lblBio.setVisible(false);
            btnEditSave.setText("Save");
        } else {
            String newBio = txtBio.getText().trim();
            userController.editProfile(viewedUser.getId(), newBio, null, null);

            viewedUser = db.getUserById(viewedUser.getId());
            lblBio.setText(viewedUser.getBio().isEmpty() ? "No bio yet" : viewedUser.getBio());
            lblBio.setVisible(true);
            txtBio.setVisible(false);
            isEditing = false;
            btnEditSave.setText("Edit Profile");

            showMessage("Success", "Profile updated!");
        }
    }

    @FXML
    public void handleBack(ActionEvent event) {
        XApplication.showTimelineView(currentUser);
    }

    private void showMessage(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
