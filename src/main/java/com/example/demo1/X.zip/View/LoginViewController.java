package com.example.demo1.View;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import javafx.scene.paint.Color;
import com.example.demo1.XApplication;
import com.example.demo1.Controller.XControllers;
import com.example.demo1.Model.User;

public class LoginViewController {
    @FXML
    private TextField txtUsername;
    @FXML
    private PasswordField txtPassword;
    @FXML
    private Label lblMessage;

    private XControllers.AuthController controller;

    @FXML
    private void initialize() {
        controller = new XControllers.AuthController();
    }

    @FXML
    public void handleAdminLogin(ActionEvent event) {
        XApplication.showAdminDashboard();
    }

    @FXML
    public void handleLogin(ActionEvent event) {
        String username = txtUsername.getText().trim();
        String password = txtPassword.getText().trim();

        if (username.isEmpty() || password.isEmpty()) {
            showMessage("enter username or password properly", Color.RED);
            return;
        }
        User user = controller.login(username, password);
        if (user != null) {
            showMessage("login successful", Color.GREEN);
            XApplication.showTimelineView(user);
        } else {
            showMessage("invalid username or password", Color.RED);
        }
    }

    @FXML
    public void handleRegister(ActionEvent event) {
        XApplication.showRegisterView();
    }

    private void showMessage(String message, Color color) {
        lblMessage.setText(message);
        lblMessage.setTextFill(color);
    }
}
