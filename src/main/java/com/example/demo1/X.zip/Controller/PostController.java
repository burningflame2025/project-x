package com.example.demo1.Controller;

import com.example.demo1.Model.Database;
import com.example.demo1.Model.Hashtag;
import com.example.demo1.Model.Post;
import com.example.demo1.Model.User;
import com.example.demo1.Model.Media;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class PostController {
    private Database db = Database.getInstance();

    public String createPost(int userId, String text, Media media, List<String> hashtagTitles, Integer parentPostId) {
        if (text == null || text.trim().isEmpty()) return "write something!";

        User user = db.getUserById(userId);
        if (user == null) return "user not found";
        if (user.isLocked()) return "user is locked!";

        int cost = user.calculatePostCost(text, media != null);
        if (!user.reduceTokens(cost)) return "not enough! need " + cost + ", have " + user.getTokens();

        Post post = new Post(text, userId, media, parentPostId);
        db.addPost(post);
        user.addPostId(post.getId());

        if (hashtagTitles != null) {
            for (String title : hashtagTitles) {
                Hashtag h = db.getOrCreateHashtag(title);
                h.addPost(post.getId());
                post.addHashtag(h.getId());
            }
        }

        db.updateUser(user);
        String type = parentPostId == null ? "Post" : "Reply";
        return type + " created! ID: " + post.getId() + " ,cost: " + cost + " ,tokens left: " + user.getTokens();
    }

    public String likePost(int userId, int postId) {
        User user = db.getUserById(userId);
        Post post = db.getPostById(postId);

        if (user == null || post == null) return "error: not found";
        if (post.isDeleted()) return "post was deleted";
        if (post.isLikedByUser(userId)) return "already liked";

        post.addLike(userId);
        return "post liked!";
    }

    public String unlikePost(int userId, int postId) {
        Post post = db.getPostById(postId);

        if (post == null) return "post not found";
        if (!post.isLikedByUser(userId)) return "not liked yet";

        post.removeLike(userId);
        return "post unliked";
    }

    public String replyToPost(int userId, int parentPostId, String text, Media media, List<String> hashtags) {
        Post parent = db.getPostById(parentPostId);
        if (parent == null) return "parent post not found";
        if (parent.isDeleted()) return "parent post is deleted";

        String result = createPost(userId, text, media, hashtags, parentPostId);

        if (result.startsWith("Post created") || result.startsWith("Reply created")) {
            List<Post> userPosts = db.getPostsByUserId(userId);
            if (!userPosts.isEmpty()) {
                Post reply = userPosts.get(userPosts.size() - 1);
                parent.addReply(reply.getId());
                return "replied to @" + (parent.getAuthorId() != -1 ? "user" : "unknown");
            }
        }
        return result;
    }

    public Post viewPost(int postId) {
        Post post = db.getPostById(postId);
        if (post != null && !post.isDeleted()) {
            post.addView();
        }
        return post;
    }

    public String deletePost(int userId, int postId) {
        Post post = db.getPostById(postId);

        if (post == null) return "post not found";
        if (post.getAuthorId() != userId) return "you can only delete your own posts";

        post.setDeleted(true);
        return "post deleted";
    }

    public List<Post> getReplies(int postId) {
        Post post = db.getPostById(postId);
        List<Post> replies = new ArrayList<>();

        if (post != null) {
            for (int id : post.getReplyIds()) {
                Post p = db.getPostById(id);
                if (p != null && !p.isDeleted()) {
                    replies.add(p);
                }
            }
        }
        return replies;
    }

    public List<Post> getHomeTimeline(int userId) {
        User user = db.getUserById(userId);
        if (user == null) return new ArrayList<>();

        List<Post> timeline = new ArrayList<>();

        for (int followingId : user.getFollowing()) {
            timeline.addAll(db.getPostsByUserId(followingId));
        }

        for (int hashtagId : user.getSelectedHashtagIds()) {
            timeline.addAll(db.getPostsByHashtagId(hashtagId));
        }

        List<Post> distinctTimeline = new ArrayList<>();
        for (Post post : timeline) {
            if (!distinctTimeline.contains(post)) {
                distinctTimeline.add(post);
            }
        }

        distinctTimeline.sort((o1, o2) -> o2.getCreatedDate().compareTo(o1.getCreatedDate()));

        int limit = 10;
        int toIndex = Math.min(limit, distinctTimeline.size());
        return new ArrayList<>(distinctTimeline.subList(0, toIndex));
    }

    public List<Post> getPopularPosts(int limit) {
        return db.getPopularPosts(limit);
    }

    public String getPostDetails(int postId) {
        Post post = db.getPostById(postId);
        if (post == null) return "post not found";
        if (post.isDeleted()) return "post is deleted";

        User author = db.getUserById(post.getAuthorId());
        if (author == null) return "author not found";

        return String.format("📝 Post #%d by @%s %s\n   Text: %s\n   ❤️ %d | 💬 %d | 👁️ %d\n   📅 %s",
                post.getId(),
                author.getUsername(),
                author.getSubscriptionBadge(),
                post.getText().length() > 50 ? post.getText().substring(0, 50) + "..." : post.getText(),
                post.getLikeCount(),
                post.getReplyCount(),
                post.getViews(),
                post.getCreatedDate()
        );
    }
}